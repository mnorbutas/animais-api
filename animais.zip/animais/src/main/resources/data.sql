INSERT INTO animais (nome, raca, idade) VALUES ('Totó', 'Beagle', 4);
INSERT INTO animais (nome, raca, idade) VALUES ('Garfield', 'Persa', 6);
INSERT INTO animais (nome, raca, idade) VALUES ('Belinha', 'Pug', 2);
INSERT INTO animais (nome, raca, idade) VALUES ('Flash', 'Tartaruga', 50);
INSERT INTO animais (nome, raca, idade) VALUES ('Piupiu', 'Calopsita', 1);