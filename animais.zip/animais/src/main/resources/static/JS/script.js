const API_URL = 'http://localhost:8080/animais';

document.addEventListener('DOMContentLoaded', () => {
    listarAnimais();
});

async function listarAnimais() {
    try {
        const resposta = await fetch(API_URL);
        const animais = await resposta.json();
        
        const tabela = document.getElementById('tabelaCorpo');
        tabela.innerHTML = '';

        animais.forEach(animal => {
            const linha = `
                <tr>
                    <td>${animal.id}</td>
                    <td>${animal.nome}</td>
                    <td>${animal.raca}</td>
                    <td>${animal.idade} anos</td>
                    <td class="actions">
                        <button class="btn-small btn-edit" onclick="prepararEdicao(${animal.id}, '${animal.nome}', '${animal.raca}', ${animal.idade})">✏️ Editar</button>
                        <button class="btn-small btn-delete" onclick="deletarAnimal(${animal.id})">🗑️ Excluir</button>
                    </td>
                </tr>
            `;
            tabela.innerHTML += linha;
        });

    } catch (erro) {
        console.error("Erro ao buscar animais:", erro);
        alert("Erro ao conectar com o Backend.");
    }
}

const formulario = document.getElementById('formAnimal');

formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();

    const id = document.getElementById('animalId').value;
    const nome = document.getElementById('nome').value;
    const raca = document.getElementById('raca').value;
    const idade = document.getElementById('idade').value;

    const dadosAnimal = { nome, raca, idade };
    const metodo = id ? 'PUT' : 'POST';
    const urlFinal = id ? `${API_URL}/${id}` : API_URL;

    try {
        const resposta = await fetch(urlFinal, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dadosAnimal)
        });

        if (resposta.ok) {
            alert(id ? "Atualizado!" : "Cadastrado!");
            limparFormulario();
            listarAnimais();
        } else {
            alert("Erro ao salvar.");
        }
    } catch (erro) {
        console.error("Erro:", erro);
    }
});

async function deletarAnimal(id) {
    if (confirm("Tem certeza?")) {
        try {
            const resposta = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
            if (resposta.ok) listarAnimais();
        } catch (erro) {
            console.error("Erro:", erro);
        }
    }
}

function prepararEdicao(id, nome, raca, idade) {
    document.getElementById('animalId').value = id;
    document.getElementById('nome').value = nome;
    document.getElementById('raca').value = raca;
    document.getElementById('idade').value = idade;
    document.getElementById('tituloFormulario').innerText = "Editar Animal";
    document.getElementById('btnSalvar').innerText = "Atualizar";
    document.getElementById('btnSalvar').style.backgroundColor = "#ffc107";
    document.getElementById('btnSalvar').style.color = "#000";
    document.getElementById('btnCancelar').style.display = "block";
}

function limparFormulario() {
    formulario.reset();
    document.getElementById('animalId').value = "";
    document.getElementById('tituloFormulario').innerText = "Novo Animal";
    document.getElementById('btnSalvar').innerText = "Salvar";
    document.getElementById('btnSalvar').style.backgroundColor = "#28a745";
    document.getElementById('btnSalvar').style.color = "#fff";
    document.getElementById('btnCancelar').style.display = "none";
}