package com.senai.animais.services;

import com.senai.animais.entities.Animal;
import com.senai.animais.repositories.AnimalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnimalService {

    @Autowired
    private AnimalRepository repository;

    public List<Animal> buscarTodos() {
        return repository.findAll();
    }

    public Animal salvar(Animal animal) {
        return repository.save(animal);
    }

    public Optional<Animal> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void deletar(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        }
    }

    public Animal atualizar(Long id, Animal animalAtualizado) {
        Optional<Animal> animalExistente = repository.findById(id);

        if (animalExistente.isPresent()) {
            Animal animal = animalExistente.get();
            // Atualização manual dos campos
            animal.setNome(animalAtualizado.getNome());
            animal.setRaca(animalAtualizado.getRaca());
            animal.setIdade(animalAtualizado.getIdade());
            return repository.save(animal);
        }
        return null;
    }
}