package com.senai.animais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimaisApplication.class, args);
	}

}
