package com.senai.animais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimaisApplicationTests {

	@Test
	void contextLoads() {
	}

}
